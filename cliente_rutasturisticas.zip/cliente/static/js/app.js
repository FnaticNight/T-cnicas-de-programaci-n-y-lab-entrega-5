// ============================================================
//  Módulo principal del aplicativo cliente de Rutas Turísticas
// ============================================================
// AngularJS (1.x) consumiendo la API REST de Spring Boot.
var app = angular.module("appRutas", []);

// URL base de la API. Si el cliente se sirve desde el mismo
// Spring Boot (carpeta static), igual funciona de forma absoluta.
// Cambiar aquí si la API corre en otro host/puerto.
app.constant("API_URL", "http://localhost:8080/api");
