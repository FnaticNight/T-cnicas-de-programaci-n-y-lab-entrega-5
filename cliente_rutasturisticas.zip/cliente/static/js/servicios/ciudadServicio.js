// ============================================================
//  Servicio de Ciudad: consume /api/ciudades
// ============================================================
app.service("CiudadServicio", function ($http, API_URL) {

    var url = API_URL + "/ciudades";

    // GET /api/ciudades/
    this.listar = function () {
        return $http.get(url + "/");
    };

    // GET /api/ciudades/{id}
    this.get = function (id) {
        return $http.get(url + "/" + id);
    };

});
