// ============================================================
//  Servicio de Parada: consume /api/paradas
// ============================================================
app.service("ParadaServicio", function ($http, API_URL) {

    var url = API_URL + "/paradas";

    // GET /api/paradas/ruta/{idRuta}  -> paradas de una ruta (ordenadas por orden)
    this.listarRuta = function (idRuta) {
        return $http.get(url + "/ruta/" + idRuta);
    };

    // POST /api/paradas/  -> agregar
    this.agregar = function (parada) {
        return $http.post(url + "/", parada);
    };

    // PUT /api/paradas/  -> modificar
    this.modificar = function (parada) {
        return $http.put(url + "/", parada);
    };

    // DELETE /api/paradas/{id}  -> eliminar
    this.eliminar = function (id) {
        return $http.delete(url + "/" + id);
    };

});
