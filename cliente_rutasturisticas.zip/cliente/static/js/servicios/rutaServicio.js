// ============================================================
//  Servicio de Ruta: consume /api/rutas
// ============================================================
app.service("RutaServicio", function ($http, API_URL) {

    var url = API_URL + "/rutas";

    // GET /api/rutas/ciudad/{idCiudad}  -> rutas de una ciudad
    this.listarCiudad = function (idCiudad) {
        return $http.get(url + "/ciudad/" + idCiudad);
    };

    // POST /api/rutas/  -> agregar
    this.agregar = function (ruta) {
        return $http.post(url + "/", ruta);
    };

    // PUT /api/rutas/  -> modificar
    this.modificar = function (ruta) {
        return $http.put(url + "/", ruta);
    };

    // DELETE /api/rutas/{id}  -> eliminar
    this.eliminar = function (id) {
        return $http.delete(url + "/" + id);
    };

});
