// ============================================================
//  Servicio de Tipo: consume /api/tipos
//  (necesario para el selector de tipo al crear/editar rutas)
// ============================================================
app.service("TipoServicio", function ($http, API_URL) {

    var url = API_URL + "/tipos";

    // GET /api/tipos/
    this.listar = function () {
        return $http.get(url + "/");
    };

});
