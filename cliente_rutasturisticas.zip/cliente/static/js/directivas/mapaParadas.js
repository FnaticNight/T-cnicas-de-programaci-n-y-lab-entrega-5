// ============================================================
//  Directiva mapaParadas: dibuja las paradas de la ruta sobre
//  un mapa Leaflet (marcadores + línea en orden + popups).
//
//  Uso:  <div mapa-paradas paradas="paradas"></div>
// ============================================================
app.directive("mapaParadas", function () {
    return {
        restrict: "A",
        scope: {
            paradas: "="
        },
        link: function (scope, element) {

            // Mapa centrado por defecto (se reajusta al cargar paradas)
            var mapa = L.map(element[0]).setView([20, 0], 2);

            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "© OpenStreetMap contributors",
                maxZoom: 19
            }).addTo(mapa);

            // Capa donde se pintan marcadores y la línea (se limpia en cada cambio)
            var capa = L.layerGroup().addTo(mapa);

            function pintar(paradas) {
                capa.clearLayers();

                if (!paradas || paradas.length === 0) {
                    mapa.setView([20, 0], 2);
                    setTimeout(function () { mapa.invalidateSize(); }, 0);
                    return;
                }

                var puntos = [];

                paradas.forEach(function (p) {
                    var lat = parseFloat(p.latitud);
                    var lng = parseFloat(p.longitud);
                    if (isNaN(lat) || isNaN(lng)) {
                        return;
                    }
                    puntos.push([lat, lng]);

                    L.marker([lat, lng])
                        .bindPopup("<b>" + p.orden + ". " + p.nombre + "</b>")
                        .addTo(capa);
                });

                // Línea que une las paradas en orden
                if (puntos.length > 1) {
                    L.polyline(puntos, { color: "#2563eb", weight: 3 }).addTo(capa);
                }

                // Ajustar la vista a todas las paradas
                if (puntos.length === 1) {
                    mapa.setView(puntos[0], 14);
                } else if (puntos.length > 1) {
                    mapa.fitBounds(puntos, { padding: [30, 30] });
                }

                // Necesario cuando el contenedor cambia de tamaño/visibilidad
                setTimeout(function () { mapa.invalidateSize(); }, 0);
            }

            // Repintar cada vez que cambie la lista de paradas
            scope.$watch("paradas", function (nuevas) {
                pintar(nuevas);
            }, true);
        }
    };
});
